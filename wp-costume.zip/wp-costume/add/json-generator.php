<?php
include_once('config.php');

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM $table_name";
$result = $conn->query($sql);

// while($row = $result->fetch_assoc()) {
	// echo $row["id"]."<hr/>\n";
	// echo $row["cover"]."<hr/>\n";
	// echo $row["judul"]."<hr/>\n";
	// echo $row["link1"]."<hr/>\n";
	// echo $row["link2"]."<hr/>\n";
// }

$row = $result->fetch_assoc();



$id	   = $row["id"];
$cover = $row["cover"];
$judul = $row["judul"];
$link1 = $row["link1"];
$link2 = $row["link2"];

$cover = str_replace("\r\n",'","',$cover);

$judul = str_replace("|",'","',$judul);
$judul = str_replace("Bab ",'<li>Bab ',$judul);
$judul = str_replace("\r\n",'</li>',$judul);

$link1 = str_replace("\r\n",'","',$link1);
$link2 = str_replace("\r\n",'","',$link2);

$txt = '
{
  "'.$id.'": {
    "cover": ["'.$cover.'"],
    "judul": ["'.$judul.'"],
    "link1": ["'.$link1.'"],
    "link2": ["'.$link2.'"]
  }
}
';


$conn->close();


$myfile = fopen("json-pdf.json", "w") or die("Unable to open file!");

fwrite($myfile, $txt);

fclose($myfile);

?>

<!DOCTYPE html>
<html>
<head>
   <!-- HTML meta refresh URL redirection -->
   <meta http-equiv="refresh"
   content="0; url=json-pdf.json">
</head>
<body>
   <p>The page has moved to:
   <a href="json-pdf.json">JSON page</a></p>
</body>
</html>