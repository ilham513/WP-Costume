<!DOCTYPE html>
<html>
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        /* CSS files add styling rules to your content */

body {
  font-family: helvetica, arial, sans-serif;
  margin: 2em;
}

h1 {
  font-style: italic;
  color: #373fff;
}


.sheva-image{
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 80%;
  padding:30px;
}

.sheva-sinopsis {
  border-top-style: dotted;
  border-right: 4px solid #E86850;
  border-bottom-style: dotted;
  border-left: 4px solid #E86850;
  padding: 16px;
  margin-bottom: 48px;
}

.sheva-table {
  border-collapse: collapse;
  width: 100%;
  padding: 16px;
  margin-bottom: 48px;  
}

.sheva-table-header{
  text-align: left;
  padding: 8px;
}

.sheva-table-data{
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
background-color: #FFE4C4;
}

.sheva-box{
  outline-style: double;
  padding: 0px 8px 8px 8px;
  margin-top:30px;
}
.sheva-box > h3{
  background-color:#E86850;
  text-align:center;
  color: white;
  display: block;
  padding: 8px;
  position: relative;
}
.sheva-box > img{
  display: block;
  margin-left: auto;
  margin-right: auto;
  border-radius: 8px;
  margin-top: 42px;  
  width: 50%;
}

.sheva-box > ul{
  margin-top:42px;
  margin-bottom:42px;
}

.sheva-box > a > button{
  width: 100%;
  background-color: #FF3333;
  font-size: 20px;
  padding: 8px;
  border-radius: 8px;
  border:0px
}
    </style>
  </head>
<body>

<div class="sheva-download-pending">
  <noscript>
      Javascript Required! Please use Chrome or Mozilla Browser.
  </noscript>
</div>
  
  
<script>
  const url = "http://sheva.my.id/wp-costume/add/json-pdf.json";
  $.getJSON( url, function( data ) {
    
  var items = [];
  $.each( data.KGYA.link1, function( key, val ) {
    
    
    items.push( 
      "<div class=\"sheva-box\">"+
      "<h3><mark>DOWNLOAD</mark> Kaguya-sama Volume "+ (key+1) +"</h3>"+
      "<img src=\""+ data.KGYA.cover[key] +"\"/>"+
      "<ul>"+
      data.KGYA.judul[key]+
      "</ul>"+
      "<a target=\"_blank\" rel=\"nofollow external noopener noreferrer\" href=\""+ data.KGYA.link1[key] +"\"><button>Download Link #1</button></a><hr/>"+
      "<a target=\"_blank\" rel=\"nofollow external noopener noreferrer\" href=\""+ data.KGYA.link2[key] +"\"><button>Download Link #2</button></a><br/>"+      
      "</div>\n"
    );
    
    
  });
    
 
  $( "<div/>", {
    "class": "sheva-download-ready",
    html: items.join( "" )
  }).appendTo( "div.sheva-download-pending" );
});
</script>

</body>
</html>