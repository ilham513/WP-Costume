<?php
include_once('config.php');

$sql 	= "SELECT * FROM $table_name LIMIT 1";
$result = $conn->query($sql);

$title 		= $_POST['title'];
$image		= $_POST['image'];
$sinopsis	= $_POST['sinopsis'];
$genre		= $_POST['genre'];
$creator	= $_POST['creator'];
$publiser	= $_POST['publiser'];
$status		= $_POST['status'];
$judul		= $_POST['judul'];
$cover		= $_POST['cover'];
$link1		= $_POST['link1'];
$link2		= $_POST['link2'];

$row = $result->fetch_assoc();

// echo "id: " . $row["id"];
?>


<!doctype html>
<html lang="en">
  <head>
<!--meta-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is Your) Virtual Assistant">
    <meta name="author" content="ilham 513">
	<link rel="icon" 								href="http://sheva.my.id/icon/favicon.ico">
<!--meta END-->

    <title>GO! WP-COSTUME</title>
	
    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body class="bg-light">
  
  
  <div id="btn-post" class="form-group container">
	<hr/><a href="https://pdf.sheva.my.id/wp-admin/post-new.php"><button id="get-html" class="btn btn-block">GO POST</button></a>
	<h3><? echo $row["title"] ?> Bahasa Indonesia PDF</h3>
	<h3><? echo $row["genre"].", ".$row["creator"].", ".$row["publiser"] ?></h3>
	<hr/>
    <textarea class="form-control" id="html-result" onclick="this.focus();this.select()" rows="18">
	




<img class="sheva-image" src="<? echo $row["image"] ?>" alt="#"/>

<div class="sheva-sinopsis"><mark>Sinopsis</mark><br/>
<? echo $row["sinopsis"] ?>
</div>

<table class="sheva-table"><center><mark>Informasi</mark></center>
  <tr>
  <th class="sheva-table-header">Judul Lengkap</th>
  <td class="sheva-table-data"><? echo $row["title"] ?></td>
  </tr>
  <tr>
  <th class="sheva-table-header">Genre</th>
  <td class="sheva-table-data"><? echo $row["genre"] ?></td>
  </tr>
  <tr>
  <th class="sheva-table-header">Creator</th>
  <td class="sheva-table-data"><? echo $row["creator"] ?></td>
  </tr>
  <tr>
  <th class="sheva-table-header">publiser</th>
  <td class="sheva-table-data"><? echo $row["publiser"] ?></td>
  </tr>
  <tr>
  <th class="sheva-table-header">Status</th>
  <td class="sheva-table-data"><? echo $row["status"] ?></td>
  </tr>
</table>

<div class="sheva-download-pending">
  <noscript>
      Javascript Required! Please use Chrome or Mozilla Browser.
  </noscript>
</div>
  
  
<script>var ID = "<? echo $row["id"] ?>";</script>	
	
	
	
	
	</textarea>
  </div>
  




  </body> 
<?php
$conn->close();
?>