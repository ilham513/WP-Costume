
<!doctype html>
<html lang="en">
  <head>
<!--meta-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is Your) Virtual Assistant">
    <meta name="author" content="ilham 513">
	<link rel="apple-touch-icon" sizes="180x180" 	href="../icon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../icon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../icon/favicon-16x16.png">
	<link rel="manifest" 							href="../icon/site.webmanifest">
	<link rel="icon" 								href="http://sheva.my.id/icon/favicon.ico">
<!--meta END-->

    <title>ADD Post WP</title>
	
    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

	<style>
	label{margin-top:22px;}
	</style>
  </head>

  <body class="jumbotron">
  
  <center><h1>Tambah Post</h1></center>
  
    <form class="form-signin" action="go.php" method="post">
	
	  <div class="form-group">
		<label>title</label>
		<input name="title" type="text" class="form-control"/>
		
		<label>image</label>
		<input name="image" type="text" class="form-control"/>
		
		<label>sinopsis</label>
		<input name="sinopsis" type="text" class="form-control"/>
		
		<label>genre</label>
		<input name="genre" type="text" class="form-control"/>
		
		<label>creator</label>
		<input name="creator" type="text" class="form-control"/>
		
		<label>publiser</label>
		<input name="publiser" type="text" class="form-control"/>
		
		<label>status</label>
		<input name="status" type="text" class="form-control"/>
				
		<label>judul</label>
		<textarea name="judul" class="form-control" rows="3"></textarea>

		<label>cover</label>
		<textarea name="cover" class="form-control" rows="3"></textarea>

		<label>Link1</label>
		<textarea name="link1" class="form-control" rows="3"></textarea>

		<label>Link2</label>
		<textarea name="link2" class="form-control" rows="3"></textarea>

	  </div>
	  
      <button class="btn btn-lg btn-primary btn-block" type="submit">Go</button>
      <p class="mt-5 mb-3 text-muted text-center">&copy; 2020</p>
    </form>
  </body>
</html>