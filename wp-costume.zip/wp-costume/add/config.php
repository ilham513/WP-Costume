<?php
$servername = "localhost";
$username = "andc6385_sb";
$password = ")wCGtCo-z7Hq";
$dbname = "andc6385_sheva";
$table_name = "pdf";
		
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>