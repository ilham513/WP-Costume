<?php
include_once('config.php');
$id 	= $_GET['id'];
$sql 	= "SELECT * FROM $table_name WHERE guid='$id'";
$result = $conn->query($sql);

?>


<!doctype html>
<html lang="en">
  <head>
<!--meta-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is Your) Virtual Assistant">
    <meta name="author" content="ilham 513">
	<link rel="apple-touch-icon" sizes="180x180" 	href="../icon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../icon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../icon/favicon-16x16.png">
	<link rel="manifest" 							href="../icon/site.webmanifest">
	<link rel="icon" 								href="http://sheva.my.id/icon/favicon.ico">
<!--meta END-->

    <title>GO! WP-COSTUME</title>

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body class="bg-light">

<div class="container pt-3">
  <form action="go-edit.php" method="post">
  <h4 class="mb-3">Edit <? echo $id; ?></h4>
	
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Post Content</label>
		<textarea name='wp-post' class="form-control" id="exampleFormControlTextarea1" rows="10">
		<? 		
		$row = $result->fetch_array();
		echo $row['post_content'];	
		?>
		</textarea>
	  </div>
	
	<hr class="mb-4">
	
	<button name="id" value="<? echo $id; ?>" 
	class="btn btn-primary btn-lg btn-block" type="submit">
		Execute!
	</button>
	
  </form>
</div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2020 - Sheva</p>
      </footer>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function() {
        'use strict';

        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');

          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
    </script>
  </body> 
<?php
$conn->close();
?>