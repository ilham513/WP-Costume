<?php
include_once('config.php');

$sql = "SELECT * FROM $table_name WHERE post_status='publish' AND post_type='post'";
$result = $conn->query($sql);

?>


<!doctype html>
<html lang="en">
  <head>
<!--meta-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="She (is Your) Virtual Assistant">
    <meta name="author" content="ilham 513">
	<link rel="apple-touch-icon" sizes="180x180" 	href="../icon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../icon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../icon/favicon-16x16.png">
	<link rel="manifest" 							href="../icon/site.webmanifest">
	<link rel="icon" 								href="http://sheva.my.id/icon/favicon.ico">
<!--meta END-->

    <title>Costum Post WP</title>
	
	 <link rel="stylesheet" href="https://harvesthq.github.io/chosen/docsupport/style.css">
  <link rel="stylesheet" href="https://harvesthq.github.io/chosen/docsupport/prism.css">
  <link rel="stylesheet" href="https://harvesthq.github.io/chosen/chosen.css">


    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.0/examples/floating-labels/floating-labels.css" rel="stylesheet">
  </head>

  <body>
    <form class="form-signin" action="go.php" method="get">
      <div class="text-center mb-4">
        <img class="mb-4" src="https://dummyimage.com/200x320/000/fff&text=MySQLi" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">Pilih ID Post</h1>
      </div>
	  <center>
	  <div class="form-label-group justify-content-center">
		  <select name="id" data-placeholder="Masukan Judul..." class="form-control-lg chosen-select" tabindex="2">
<?php
if ($result->num_rows > 0) {
    while($row = $result->fetch_array()) {
        echo '<option value="'.$row["guid"].'">'.$row["post_title"].'</option>';	
    }
}	
?>		  
		  </select>
		</div>
		</center>
		</div>

      <button class="btn btn-sm btn-primary btn-block" type="submit">Go</button>
      <p class="mt-5 mb-3 text-muted text-center">&copy; 2020</p>
    </form>
  </body>
  
<script src="https://harvesthq.github.io/chosen/docsupport/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="https://harvesthq.github.io/chosen/chosen.jquery.js" type="text/javascript"></script>
<script src="https://harvesthq.github.io/chosen/docsupport/prism.js" type="text/javascript" charset="utf-8"></script>
<script src="https://harvesthq.github.io/chosen/docsupport/init.js" type="text/javascript" charset="utf-8"></script>
</html>

<?php
$conn->close();
?>