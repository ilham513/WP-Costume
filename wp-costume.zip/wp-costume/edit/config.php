<?php
// $servername = "localhost";
// $username = "andc6385_sb";
// $password = ")wCGtCo-z7Hq";
// $dbname = "andc6385_sheva";
// $table_name = "pdf";
	
$servername = "localhost";
$username = "andc6385";
$password = "TNYiKBtPh9o0qbM1SVra";
$dbname = "andc6385_wp553";
$table_name = "wp5o_posts";
	
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>