<head>
  <meta http-equiv='refresh' content='3; URL=.'>
</head>

<?
include_once('config.php');
$post 	= $_POST['wp-post'];
$id		= $_POST['id'];;
$sql	= "UPDATE $table_name SET post_content='$post' WHERE guid='$id'";
$result = $conn->query($sql);

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully <a href='.'>Kembali ke awal.</a>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}